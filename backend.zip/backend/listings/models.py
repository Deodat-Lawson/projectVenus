from django.contrib.gis.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission
from random import choices
from django.utils import timezone
from django.contrib.gis.geos import Point
from django.contrib.auth import get_user_model
User = get_user_model()

# Create your models here.
class Listing(models.Model):
    contributer = models.ForeignKey(User, on_delete=models.CASCADE, blank=True)
    title = models.CharField(max_length=150)
    description = models.TextField(null=True, blank=True)
    choices_area = (    
        ('Vancouver', 'Vancouver'),
        ('Baltimore', 'Baltimore'),
    )
    area = models.CharField(max_length=20, blank=True, null=True, choices=choices_area)
    choices_listing_type = (
        ('Community Center', 'Community Center'),
    )
    listing_type = models.CharField(max_length=20, choices=choices_listing_type)
    latitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)
    # location = models.PointField(blank=True, null=True, srid=4326)
    groups = models.ManyToManyField(Group, related_name='listings_user_set', blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name='listings_user_permissions_set', blank=True)
    picture1 = models.ImageField(blank=True, null=True, upload_to="pictures/%Y/%m/%d/")

    def __str__(self):
        return self.title