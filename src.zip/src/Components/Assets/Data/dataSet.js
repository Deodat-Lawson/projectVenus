import image1 from "../background1.jpg"
const myListings = [
{
    id: 1,
    title: "Community Center 1",
    type: "Community Center",
    description: "Dunbar Community Center Descriptions",
    picture1: "image1",
    location: {
        type: "point",
        coordinates: [51.02, -0.9],
    },
},


]