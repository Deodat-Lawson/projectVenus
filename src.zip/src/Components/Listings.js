import React, {useEffect, useState} from "react";
import { MapContainer, TileLayer, Popup, Marker, useMap } from 'react-leaflet';
import { Icon } from "leaflet"; 
import Axios from 'axios';


import { AppBar, Grid, Typography, Button, CardHeader, CardMedia, CardContent, Card, CircularProgress } from "@mui/material";
import 'leaflet/dist/leaflet.css';

//icons
import communityCenterIconPNG from './Assets/Mapicons/community center icon.png';
import dentistIconPNG from './Assets/Mapicons/dentist icon.png';
import drugstoreIconPNG from './Assets/Mapicons/drugstore icon.png';
import hospitalIconPNG from './Assets/Mapicons/ophthalmologist icon.png';
import therapyIconPNG from './Assets/Mapicons/therapy icon.png';
import veterinaryIconPNG from './Assets/Mapicons/veterinary icon.png';

//Assets
import img1 from "./Assets/background1.jpg";
import myListings from "./Assets/Data/dataSet"

function Listings() {
    // fetch('http://localhost:8000/api/listings/').then(response=> response.json()).then(data=>console.log(data));

    const communityCenterIcon = new Icon({
        iconUrl: communityCenterIconPNG,
        iconSize: [40, 40],
    });

    const dentistIcon = new Icon({
        iconUrl: dentistIconPNG,
        iconSize: [40, 40],
    });

    const drugstoreIcon = new Icon({
        iconUrl: drugstoreIconPNG,
        iconSize: [40, 40],
    });


    const [allListings, setAllListings] = useState([]);
    const [dataIsLoading, setDataIsLoading] = useState(true);

    useEffect(()=>{
        const source = Axios.CancelToken.source();
        async function GetAllListings() {
            try{
                const response = await Axios.get('http://localhost:8000/api/listings/', {cancelToken: source.token});
                setAllListings(response.data);
                setDataIsLoading(false);
            } catch(error){

            }
        }
        GetAllListings();
        return ()=>{
            source.cancel();
        }
    },[]);

    const [latitude, setLatitude] = useState(51.505)
    const [longitude, setLongitude] = useState(-0.09)

    if(dataIsLoading === false){
        console.log(allListings[0].location);
    }
    
    if(dataIsLoading === true){
        return 
        <Grid container justifyContent="center" alignItems="center" style={{
            height: '100vh'
        }}>
            <CircularProgress />
        </Grid>;
    }


    return (
        <Grid container>
            <Grid item xs={4}>
                {allListings.map((listing)=>{
                    return(
                        <Card key = {listing.id} style={{
                            margin: "0.5rem",
                            border: "1px solid black",
                            position: "relative",
                        }}>

                            <CardHeader title={listing.title} />
                            <CardMedia style={{
                                paddingRight: "1rem",
                                paddingLeft: "1rem",
                                height: "20rem",
                                width: "30rem",

                            }}
                            component="img"
                            image = {listing.picture1}
                            alt = {listing.title} />

                            <CardContent>
                                <Typography variant = "body2">
                                    {listing.description.substring(0,200)}...
                                </Typography>
                            </CardContent>

                        </ Card>
                    )
                })}
            </Grid>

            <Grid item xs={8} style={{marginTop: "0.5rem"}}>
                <AppBar position="sticky">


                {allListings.map((listing)=>{
                    return(
                        <div style={{
                            height: "100vh"
                        }}>
                            <MapContainer center={[51.505, -0.09]} zoom={16} scrollWheelZoom={true}>
                                <TileLayer
                                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                />
    
                                <Marker icon={communityCenterIcon} position={[listing.latitude, listing.longitude]}>
                                    <Popup>
                                        <Typography variant="h5"> Name </Typography>
                                        <img src={listing.picture1} style={{
                                            height: "14rem",
                                            width: "18rem"
                                        }} />
                                        <Typography variant="body1"> Description </Typography>
                                        <Button variant="contained" fullWidth> Link </Button>
                                    </Popup>
                                </Marker>
                            </MapContainer>
                        </div>
                    )
                })}

                    

                </AppBar>
            </Grid>
        </Grid>




    );
}

export default Listings;