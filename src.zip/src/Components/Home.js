import React, {useState} from "react";
import {Link} from "react-router-dom";
import {Button, Typography, Grid, IconButton, AppBar, Toolbar} from "@mui/material";

import CssBaseline from "@mui/material/CssBaseline";
import background1 from './Assets/background1.jpg';
import Header from "./Header";

function Home(){
    const [btnColor, setBtnColor] = useState("error");
    
    return(
        <>
        <CssBaseline />

        <div style={{position: "relative"}}>
        <img src={background1} style={{
            width: "100%",
            height: "92vh"
        }}/>

        <div style={{
            position: "absolute",
            zIndex: "100",
            top: "100px",
            left: "20px",
            textAlign: "center"
        }}>
            <Typography variant="h1" style={{
                color:"white",
                fontWeight: "bolder"

            }}> FIND THE <span style={{color: "#0288D1"}}> PHARMACY </span> THAT MEETS YOUR NEEDS </Typography>

            <Button variant="contained" style={{
                fontSize: "3.5rem",
                borderRadius: "15px",
                backgroundColor: "#0288D1",
                marginTop: "2rem",
                boxShadow: "3px 3px 3px white"
            }}> Search For Your PHARMACY</Button>
        </div>
        </div>
        </>
    );
}

export default Home;