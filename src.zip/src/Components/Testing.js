import React, {useState, useEffect, useReducer, useDeferredValue } from 'react';

function Testing(){
    // const [count, setCount] = useState(1);
    // useEffect(()=>{

    // },[count]);

    // function IncreaseCount(){
    //     setCount((current)=>current + 1)
    // }

    // function DecreaseCount(){
    //     setCount((current)=>current - 1)
    // }

    const initialState = {
        appleCount: 1,
        banaCount: 10,
        message: "Hello",
        happy: false,
    };

    function ReducerFunction(state, action){
        switch(action.type){
            case 'addApple':
                return {
                    appleCount: state.appleCount + 1,
                    banaCount: state.banaCount,
                    message: state.message,
                    happy: state.happy,
                };
        }

    }



    const [state, dispatch] = useReducer(ReducerFunction, initialState)



    return (
        <>
        <div>Right now the count of apple is {state.appleCount}</div>
        <br />
        <button onClick={()=>dispatch({
            type: 'addApple'

        })}>Add Apple</button>
        </>
    );
}

export default Testing;