import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, Typography, Grid, IconButton, AppBar, Toolbar, Menu, MenuItem } from "@mui/material";
import Axios from 'axios';

import CssBaseline from "@mui/material/CssBaseline";
import background1 from './Assets/background1.jpg';

//Context
import StateContext from "../Contexts/StateContext"
import DispatchContext from "../Contexts/DispatchContext";


function Header() {
    <CssBaseline />
    const navigate = useNavigate();

    const GlobalState = useContext(StateContext);
    const GlobalDispatch = useContext(DispatchContext);

    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    async function HandleLogout(){
        setAnchorEl(null);

        try{
            const response = await Axios.post('http://localhost:8000/api-auth-djoser/token/logout/', GlobalState.userToken, {headers: { Authorization: "Token ".concat(GlobalState.userToken)}});
            console.log(response);
            GlobalDispatch({type: "logout"});
            navigate("/");

        }catch(e){
            console.log(e.response);
        }

    }

    return <AppBar position="static" style={{
        backgroundColor: " #E0F7FA",
        color: "#333",
        margin: "0",
        padding: "0",
    }}>
        <Toolbar>
            <div style={{
                marginRight: "auto",
            }}>
                <Button color="inherit" onClick={() => navigate("/")}> <Typography variant="h4">Project Venus</Typography>{" "} </Button>
            </div>

            <div style={{
                marginLeft: "auto",
                marginRight: "30rem",
            }}>
                <Button color="inherit" style={{
                    marginRight: "2rem"
                }} onClick={() => navigate("/listings")}>
                    <Typography variant="h6"> Listings </Typography>{" "} </Button>
                <Button color="inherit" style={{
                    marginLeft: "2rem"
                }}> {" "}<Typography variant="h6"> Agencies </Typography>{" "}</Button>
            </div>

            <div>
                <Button color="inherit" style={{
                    backgroundColor: "#0288D1",
                    color: "#fff",
                    width: "15rem",
                    fontSize: "1.1rem",
                    marginRight: "1rem",
                }}
                onClick={()=>navigate("/addproperty")}
                > Add Property</Button>

                {GlobalState.userIsLogged ? (<Button color="inherit" style={{
                    backgroundColor: "white",
                    color: "black",
                    width: "15rem",
                    fontSize: "1.1rem",
                    marginLeft: "1rem",
                }}
                onClick={handleClick}
                >
                    {GlobalState.userUsername}
                </Button>)
                    : (<Button color="inherit" style={{
                        backgroundColor: "white",
                        color: "black",
                        width: "15rem",
                        fontSize: "1.1rem",
                        marginLeft: "1rem",
                    }} 
                    
                    onClick={() => navigate("/login")}
                    >Login</Button>)}

                <Menu
                    id="basic-menu"
                    anchorEl={anchorEl}
                    open={open}
                    onClose={handleClose}
                    MenuListProps={{
                        'aria-labelledby': 'basic-button',
                    }}
                >
                    <MenuItem style={{
                        color: 'black',
                        backgroundColor: '',
                        width: '15rem',
                        fontWeight: 'bolder',
                        borderRadius: '15px',
                        marginBottom: '0.25rem',
                    }} onClick={handleClose}>Profile</MenuItem>
                    <MenuItem style={{
                        color: 'black',
                        backgroundColor: '',
                        width: '15rem',
                        fontWeight: 'bolder',
                        borderRadius: '15px',
                    }}
                    onClick={HandleLogout}>Logout</MenuItem>
                </Menu>

            </div>

        </Toolbar>

    </AppBar>;
}

export default Header;