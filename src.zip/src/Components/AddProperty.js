import React, { useEffect, useState, useReducer, useRef, useMemo } from 'react';
import Axios from "axios";

import { useNavigate } from 'react-router-dom';
import { AppBar, Grid, Typography, Button, CardHeader, CardMedia, CardContent, Card, CircularProgress, TextField } from "@mui/material";
import { useImmerReducer } from 'use-immer';
import { MapContainer, TileLayer, useMap, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'

function AddProperty() {
    const navigate = useNavigate();

    const initialState = {
        titleValue: '',
        listingTypeValue: '',
        descriptionValue: '',
        latitudeValue: '',
        longitudeValue: '',
        mapInstance: null,
        areaValue: '',
        markerPosition: {
            lat: '49.246292',
            lng: '-123.116226',
        },
        uploadedPictures: [],
        picture1Value: "",

    };

    function ReducerFunction(draft, action) {
        switch (action.type) {
            case "catchTitleChange":
                draft.titleValue = action.titleChosen;
                break;
            case "catchListingTypeChange":
                draft.listingTypeValue = action.listingTypeChosen;
                break;
            case "catchDescriptionChange":
                draft.descriptionValue = action.descriptionChosen;
                break;
            case "catchLatitudeChange":
                draft.latitudeValue = action.latitudeChosen;
                break;
            case "catchLongitudeChange":
                draft.longitudeValue = action.longitudeChosen;
                break;
            case "catchAreaChange":
                draft.areaValue = action.areaChosen;
                break;
            case 'getMap':
                draft.mapInstance = action.mapData;
                break;
            case 'catchMarkerChange':
                draft.markerPosition.lat = action.changeLatitude;
                draft.markerPosition.lng = action.changeLongitude;
                draft.latitudeValue = '';
                draft.longitudeValue = '';
                break;
            case 'catchPicture1Change':
                draft.picture1Value = action.picture1Chosen;
                break;

            case 'catchUploadedPictures':
                draft.uploadedPictures = action.picturesChosen;
                break;
        }
    }

    const [state, dispatch] = useImmerReducer(ReducerFunction, initialState);

    function TheMapComponent() {
        const map = useMap();
        dispatch({ type: 'getMap', mapData: map });
        return null;
    }


    useEffect(() => {
        if (state.areaValue === 'Vancouver') {

            if (state.mapInstance === null) {
                console.log("null");
            }
            else {
                state.mapInstance.setView([49.246292, -123.116226], 12);
                dispatch({ type: 'catchMarkerChange', changeLatitude: 49.246292, changeLongitude: -123.116226 });
            }

        }
        else if (state.areaValue === 'Baltimore') {

            if (state.mapInstance === null) {
                console.log("null");
            }
            else {
                state.mapInstance.setView([39.299236, -76.609383], 12);
                dispatch({ type: 'catchMarkerChange', changeLatitude: 39.299236, changeLongitude: -76.609383 });
            }

        }
    }, [state.areaValue]);


    const areaOptions = [{
        value: '',
        label: '',
    },
    {
        value: 'Vancouver',
        label: 'Vancouver',
    },
    {
        value: 'Baltimore',
        label: 'Baltimore',
    }]

    //Draggable Marker
    const markerRef = useRef(null)
    const eventHandlers = useMemo(
        () => ({
            dragend() {
                const marker = markerRef.current;
                dispatch({ type: 'catchLatitudeChange', latitudeChosen: marker.getLatLng().lat });
                dispatch({ type: 'catchLongitudeChange', longitudeChosen: marker.getLatLng().lng });
            },
        }),
        [],
    )

    useEffect(() => {
        if (state.uploadedPictures[0]) {
            dispatch({ type: 'catchPicture1Change', picture1Chosen: state.uploadedPictures[0] });
        }
    },[state.uploadedPictures[0]]);


    function FormSubmit(e) {
        e.preventDefault();
        console.log("submitted form");
        console.log(state.uploadedPictures);
        // dispatch({type: 'changeSendRequest'});
    }

    return (<div style={{
        width: '50%',
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: '3rem',
        border: '5px solid black',
        padding: '3rem',
    }}>
        <form onSubmit={FormSubmit}>
            <Grid item container justifyContent="Center">
                <Typography variant="h4">SUBMIT A BUILDING</Typography>
            </Grid>

            <Grid item container style={{ marginTop: '1rem' }}>
                <TextField
                    id="title"
                    label="Title"
                    variant="outlined"
                    fullWidth
                    value={state.titleValue}
                    onChange={(e) => dispatch({ type: 'catchTitleChange', titleChosen: e.target.value })}
                />
            </Grid>

            <Grid item container style={{ marginTop: '1rem' }}>
                <TextField
                    id="listingType"
                    label="Listing Type"
                    variant="standard"
                    fullWidth
                    value={state.listingTypeValue}
                    onChange={(e) => dispatch({ type: 'catchListingTypeChange', listingTypeChosen: e.target.value })}
                />
            </Grid>

            <Grid item container style={{ marginTop: '1rem' }}>
                <TextField
                    id="description"
                    label="Description"
                    variant="standard"
                    fullWidth
                    value={state.descriptionValue}
                    onChange={(e) => dispatch({ type: 'catchDescriptionChange', descriptionChosen: e.target.value })}
                />
            </Grid>

            <Grid item container style={{ marginTop: '1rem' }}>
                <TextField
                    id="description"
                    label="Description"
                    variant="standard"
                    fullWidth
                    value={state.descriptionValue}
                    onChange={(e) => dispatch({ type: 'catchDescriptionChange', descriptionChosen: e.target.value })}
                />
            </Grid>

            <Grid item container style={{ marginTop: '1rem' }}>
                <TextField
                    id="area"
                    label="Area"
                    variant="standard"
                    fullWidth
                    value={state.areaValue}
                    onChange={(e) => dispatch({ type: 'catchAreaChange', areaChosen: e.target.value })}
                    select
                    SelectProps={{
                        native: true,
                    }}
                >
                    {areaOptions.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}

                </TextField>
            </Grid>

            <Grid item container style={{
                height: '35rem',
                marginTop: '1rem',
            }}>
                <MapContainer center={[51.505, -0.09]} zoom={13} scrollWheelZoom={false}>
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <TheMapComponent />

                    <Marker
                        draggable
                        eventHandlers={eventHandlers}
                        position={state.markerPosition}
                        ref={markerRef}>
                    </Marker>
                </MapContainer>

            </Grid>

            <Grid item container xs={6} style={{ marginTop: '1rem', marginLeft: "auto", marginRight: "auto" }}>
                <Button variant="contained" fullWidth type="submit"
                    component="label"
                    style={{
                        color: "white",
                        frontSize: "0.8rem",
                        border: "1px solid black",
                        marginLeft: "1rem",
                    }}>UPLOAD A PHOTO
                    <input type="file"
                        multiple
                        accept='image/png, image/gif, image/jpeg'
                        hidden
                        onChange={(e) => dispatch({ type: 'catchUploadedPictures', picturesChosen: e.target.files })}
                    />

                </Button>
            </Grid>

            <Grid item container>
                <ul>
                    {state.picture1Value ? <li>{state.picture1Value.name}</li> : ""}
                </ul>

            </Grid>


            <Grid item container xs={8} style={{ marginTop: '1rem', marginLeft: "auto", marginRight: "auto" }}>
                <Button variant="contained" fullWidth type="submit" style={{
                    color: "white",
                    frontSize: "1.1rem",
                    marginLeft: "1rem",
                }}>SUBMIT</Button>
            </Grid>


        </form>




    </div>);
}

export default AddProperty;